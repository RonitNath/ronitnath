# @isoastra/fleet-runtime

Small process-lifecycle primitives for fleet applications. Imports are inert:
the executable that owns a process decides whether to install signal and IPC
handlers. Disposers run once in reverse registration order.
