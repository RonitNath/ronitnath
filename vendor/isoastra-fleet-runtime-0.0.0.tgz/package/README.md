# @isoastra/fleet-runtime

Small process-lifecycle primitives for fleet applications. Imports are inert:
the executable that owns a process decides whether to install signal and IPC
handlers. Disposers run once in reverse registration order.
Supervisors may send `quiesce` before `drain`; children acknowledge it with a
typed `quiesced` message after new ingestion has stopped.
