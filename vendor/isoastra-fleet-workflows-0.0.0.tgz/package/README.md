# @isoastra/fleet-workflows

DBOS is the selected durable execution runtime for fleet projects (Ronit, 2026-09-11).
This adopts DBOS following the pg-boss/DBOS experiment; its earlier pg-boss-first
recommendation is superseded by this choice. Package adoption is not deployment
into an existing app.

The root entry point re-exports the native DBOS SDK. `./events` bridges committed
`fleet-events` rows into durable workflow starts. Projects own their activity
windows, interpretation, notification policies, and billing rules. The package
does not define a second workflow language or infer intent automatically.

## Worker integration

Install this package, `@dbos-inc/dbos-sdk@4.27.6`, and `pg`. Keep one SDK instance
in the process. Register workflows before launch; keep DBOS and application
workflow modules external to application bundlers. Run a dedicated Node worker,
not a React/edge entry point. The root export uses the installed SDK directly.

```ts
import { DBOS, WorkflowQueue } from '@isoastra/fleet-workflows';
import { dispatchEvents, type DomainEvent } from '@isoastra/fleet-workflows/events';
import pg from 'pg';

const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
new WorkflowQueue('activity', { concurrency: 10 });
const activity = DBOS.registerWorkflow(async (event: DomainEvent) => {
  // Durable I/O belongs in steps. Domain policy can ignore irrelevant events.
  if (event.resourceKind !== 'document') return;
  await DBOS.runStep(async () => {
    // Feed the event into the app's persisted activity buffer here.
    // Use event.orgId + event.seq to deduplicate at the destination.
  }, { name: 'accumulate', retriesAllowed: true, maxAttempts: 5 });
}, { name: 'documentActivity' });

DBOS.setConfig({
  name: 'my-app',
  systemDatabaseUrl: process.env.WORKFLOW_DATABASE_URL!,
  executorID: process.env.WORKFLOW_EXECUTOR_ID!,
  applicationVersion: process.env.APP_VERSION!,
  runMigrations: false,
});
await DBOS.launch();

const batch = await dispatchEvents({
  pool, namespace: 'my-app', consumer: 'document-activity:v1', orgId: 'acme',
  workflow: activity, queueName: 'activity', limit: 100,
});
// batch.cursor acknowledges durable starts, not successful workflow completion.
```

Apply `WORKFLOW_DISPATCH_MIGRATION` with the application's migration runner in
the source database, after `DOMAIN_EVENT_MIGRATION`. Apply DBOS system-schema
migrations separately before launching workers with `runMigrations: false`.
Source and DBOS databases can differ. Do not pass the source transaction/pool
client to DBOS or assume the two writes are one transaction.

The application owns polling for each subscribed organization, concurrency
between streams and orderly worker shutdown. `startEventIngestion` supplies a
cancellable, fair polling loop with bounded concurrency and error backoff.
Periodic polling remains required to recover missed notices. Do not call the
dispatcher from inside a workflow or step; it is an external ingestion loop.

## Delivery and ordering contract

- A cursor starts at zero for each `(namespace, consumer, orgId)`. Initial use
  replays retained history. Namespace identifies the source app, including when
  several apps share a DBOS system database. Consumer identifies the semantic
  subscription, not a transient worker or deployment.
- The source transaction lock serializes competing dispatchers for one stream.
  The batch is bounded; set source-pool connection/query timeouts for the app's
  environment. Other streams can dispatch concurrently.
- Starts are durable before the source cursor advances. A crash before cursor
  commit repeats the same workflow IDs. IDs encode source, consumer, org, and
  exact decimal sequence. They do not change with worker or code version.
- Events are dispatched in source sequence order. **Execution/completion order
  is not guaranteed**: workflows and steps may run concurrently. Use application
  state locks, version checks, or an appropriate DBOS queue for ordered effects.
- Cursor progress means accepted by DBOS. Workflow failures remain visible in
  DBOS and require its retry/resume operations; resetting a cursor does not retry
  a failed workflow under an existing ID.
- DBOS ID deduplication depends on retaining its execution history. Keep durable
  application/provider effect identities for billing and notifications beyond
  runtime-history retention. Completed steps avoid repetition after checkpoint;
  an external effect can still succeed before the checkpoint is written.
- This reader returns actor context and payloads, unlike browser refresh frames.
  Use only on trusted workers with source DB access. Workflows must recheck
  recipient access and preferences at delivery. A correlation ID in the event is
  evidence; it does not automatically establish ambient actor context in workers.
- A gap before the next event fails the batch. The bridge expects the gapless,
  append-only fleet event log; it does not reset a cursor over pruned history.
  Keep subscription names stable across deployment; a new consumer replays from
  zero. Do not reuse a consumer for a different workflow contract accidentally.

Executor identity and application version are deployment decisions. The native
DBOS recovery/versioning model applies; an arbitrary new executor ID is not a
replacement-host recovery strategy. Keep or deliberately migrate pending workflow
versions rather than changing their step structure without a rollout policy.

`startEventIngestion()` applies retry eligibility per stream, so an unhealthy
stream never occupies a concurrency slot while it backs off. Discovery errors
are isolated per subscription and may be observed with `onDiscoveryError`.
Discovery runs independently per subscription, and dispatch slots are refilled
as soon as one stream finishes. A stalled operation therefore occupies only
its own subscription or concurrency slot.

`stop()` prevents new work. `done` waits for in-flight dispatch through the
bounded `stopTimeoutMs` quiesce deadline (20 seconds by default). `settled`
retains an unbounded acknowledgement for owners that must observe every started
discovery and dispatch actually finish before disposing shared resources.

## Validation

`pnpm gate` builds both ESM/CJS, typechecks, lints, and runs unit tests.
After building, run the actual Postgres/DBOS integration suite:

```sh
TEST_PG_BIN=/opt/homebrew/opt/postgresql@16/bin pnpm --filter @isoastra/fleet-workflows test:integration
```

The suite starts its own disposable loopback Postgres, uses the public `emit()`
API and package builds, runs competing OS workers, and SIGKILLs workers across
cursor acknowledgment and step checkpoint boundaries. It sends no external
messages and makes no paid model calls. It does not validate a production DB
failover, runtime-history pruning, deployment-version migration, or real model
quality. The temporary database is stopped and retained for diagnosis.
