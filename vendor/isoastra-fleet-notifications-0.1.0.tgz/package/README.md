# @isoastra/fleet-notifications

Headless notification state, evidence, aggregation policy, delivery, and DBOS
registration for fleet applications. The library owns durable notification and
delivery mechanics. Applications own domain interpretation, authorization,
recipient preferences, rendering, credentials, and user interfaces.

Imports are inert. Apply `NOTIFICATION_MIGRATION` after the fleet-events and
workflow cursor migrations. Register DBOS workflows before the application
launches its single DBOS SDK instance. PostgreSQL commands that must commit with
a domain mutation accept the caller's transaction.

```ts
import { PostgresNotificationStore } from "@isoastra/fleet-notifications/postgres";
import { createNotificationEventSubscription, initializeNotificationEventBoundary } from "@isoastra/fleet-notifications/events";
import { startEventIngestion } from "@isoastra/fleet-workflows/events";

const store = new PostgresNotificationStore(pool, authorization);
const subscription = createNotificationEventSubscription({
  adapter: documentNotifications,
  store,
  pool,
  discoverStreams: async () => authorizedTenantIds(),
});

// Required once per stream. `latest` prevents accidental historical mail.
await initializeNotificationEventBoundary(client, {
  namespace: "documents", consumer: subscription.consumer,
  orgId: "acme", startAfter: "latest",
});
const ingestion = startEventIngestion({ pool, namespace: "documents", subscriptions: [subscription] });
```

Notification identity is stable per tenant, recipient, subject, and application
group key. Revisions preserve immutable content/evidence history. Read revision,
dismissal, content revision, and last alerted revision remain independent. A
delivery snapshot may reference several notifications without merging them.

Policy functions are deterministic and take explicit timestamps. Applications
compose immediate, inactivity, fixed-window, leading/trailing, maximum-wait,
maximum-input, and recipient-budget behavior. Persist their chosen policy ID and
version with every revision.

Email transports return accepted, rejected, transient, or uncertain outcomes.
useSend receives the stable idempotency key in `Idempotency-Key`. SMTP receives
a stable `Message-ID`, which is evidence but is not a deduplication guarantee.
Applications declare real provider guarantees and their retention window.

`RevisionProposal` is the complete agent/human extension boundary. It contains
content, expected revision, and provenance. The store rechecks authorization and
rejects stale revisions. This package has no dependency on an agent or inference
library.

During shutdown, stop event ingestion and the notification scheduler before
DBOS and database pools. Await full settlement before disposing shared pools;
bounded quiesce alone does not transfer resource ownership.
